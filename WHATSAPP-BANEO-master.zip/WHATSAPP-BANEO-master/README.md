# WHATSAPP-BANO
este git funciona para banear el WhatsApp de la victima 
pero no siempre funciona el baneo por cuestiones del token 
el script solo funciona para mexico compañia telcel 
# NINGUN SISTEMA ES SEGURO
# CREADOR : HACKING PCH
